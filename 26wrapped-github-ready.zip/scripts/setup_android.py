from pathlib import Path
import shutil,re
import xml.etree.ElementTree as ET
root=Path('android/app/src/main')
java=root/'java/app/wrapped26/mobile'; java.mkdir(parents=True,exist_ok=True)
for name in ['MainActivity.java','CameraRollPlugin.java']: shutil.copyfile(Path('native')/name,java/name)
ns='http://schemas.android.com/apk/res/android'; ET.register_namespace('android',ns)
p=root/'AndroidManifest.xml'; tree=ET.parse(p); manifest=tree.getroot()
for name,extra in [('READ_MEDIA_IMAGES',{}),('READ_EXTERNAL_STORAGE',{'maxSdkVersion':'32'})]:
    full='android.permission.'+name
    if not any(x.get('{'+ns+'}name')==full for x in manifest.findall('uses-permission')):
        manifest.insert(0,ET.Element('uses-permission',{'{'+ns+'}name':full,**{'{'+ns+'}'+k:v for k,v in extra.items()}}))
tree.write(p,encoding='utf-8',xml_declaration=True)
p=root/'res/xml/file_paths.xml'; tree=ET.parse(p); tree.getroot().append(ET.Element('cache-path',{'name':'wrapped_shared','path':'shared/'})); tree.write(p,encoding='utf-8',xml_declaration=True)
p=Path('android/variables.gradle'); s=p.read_text(); s=re.sub(r'minSdkVersion\s*=\s*\d+','minSdkVersion = 28',s); p.write_text(s)
