# 26wrapped — GitHub build kit

1. Create a GitHub repository called 26wrapped.
2. Extract this ZIP and upload ALL contents to the repository root, including the hidden .github directory. Do not upload just the ZIP. GitHub web upload may require creating .github/workflows/build.yml manually using Add file > Create new file and pasting the supplied workflow.
3. Commit to main. Open Actions > Build 26wrapped APK > Run workflow (or use the automatic push build).
4. After a successful build, download the 26wrapped-install-package artifact. Extract it.
5. Upload 26wrapped-netlify.zip to Netlify Drop. The landing page and APK must be deployed together. Share the resulting HTTPS URL.

Pilot APK uses Gradle debug signing; no production signing or stable upgrade key is configured. Android 9+; on Android 14+ select full photo access rather than limited access. The Android OS may ask to allow installing unknown apps. Test on a real device before distribution. The build has not been executed here. No iOS installation is provided by this workflow.

Native app processes photos locally and draws 12 readable 2026 images randomly. Review the collage before sharing.
