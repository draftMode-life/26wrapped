package app.wrapped26.mobile;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity { @Override public void onCreate(Bundle state){registerPlugin(CameraRollPlugin.class);super.onCreate(state);} }
