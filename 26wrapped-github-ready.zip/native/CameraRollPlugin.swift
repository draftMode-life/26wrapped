import Foundation
import Capacitor
import Photos
import UIKit
@objc(CameraRollPlugin) public class CameraRollPlugin: CAPPlugin, CAPBridgedPlugin {
 public let identifier = "CameraRollPlugin"
 public let jsName = "CameraRoll"
 public let pluginMethods: [CAPPluginMethod] = [CAPPluginMethod(name: "randomPhotos", returnType: CAPPluginReturnPromise), CAPPluginMethod(name: "shareCollage", returnType: CAPPluginReturnPromise)]
 @objc func randomPhotos(_ call: CAPPluginCall) {
  PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
   guard status == .authorized else { call.reject("Allow full photo access in Settings."); return }
   DispatchQueue.global(qos: .userInitiated).async {
    let cal = Calendar.current
    let start = cal.date(from: DateComponents(year: 2026, month: 1, day: 1))!
    let end = cal.date(from: DateComponents(year: 2027, month: 1, day: 1))!
    let options = PHFetchOptions(); options.predicate = NSPredicate(format: "creationDate >= %@ AND creationDate < %@", start as NSDate, end as NSDate)
    let assets = PHAsset.fetchAssets(with: .image, options: options)
    let request = PHImageRequestOptions(); request.isSynchronous = true; request.deliveryMode = .highQualityFormat; request.isNetworkAccessAllowed = false; request.resizeMode = .exact
    var photos: [String] = []
    for i in Array(0..<assets.count).shuffled() {
     autoreleasepool { PHImageManager.default().requestImage(for: assets.object(at: i), targetSize: CGSize(width: 1000, height: 1000), contentMode: .aspectFit, options: request) { image, info in
      if let data = image?.jpegData(compressionQuality: 0.88) { photos.append(data.base64EncodedString()) }
     } }
     if photos.count >= 12 { break }
    }
    guard photos.count == 12 else { call.reject("12 readable local 2026 photos required."); return }; call.resolve(["photos": photos])
   }
  }
 }
 @objc func shareCollage(_ call: CAPPluginCall) { guard let raw = call.getString("data"), let data = Data(base64Encoded: raw) else { call.reject("Invalid image"); return }; DispatchQueue.main.async { do { let url = FileManager.default.temporaryDirectory.appendingPathComponent("26wrapped-2026.jpg"); try data.write(to: url); let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil); guard let host = self.bridge?.viewController else { call.reject("Sharing unavailable"); return }; vc.popoverPresentationController?.sourceView = host.view; vc.popoverPresentationController?.sourceRect = CGRect(x: host.view.bounds.midX, y: host.view.bounds.midY, width: 1, height: 1); host.present(vc, animated: true); call.resolve() } catch { call.reject("Sharing failed") } } }
}
