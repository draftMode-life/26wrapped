package app.wrapped26.mobile;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.core.content.FileProvider;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.util.*;
@CapacitorPlugin(name="CameraRoll", permissions={@Permission(alias="photos",strings={Manifest.permission.READ_MEDIA_IMAGES}),@Permission(alias="legacy",strings={Manifest.permission.READ_EXTERNAL_STORAGE})})
public class CameraRollPlugin extends Plugin {
 @PluginMethod public void randomPhotos(PluginCall call){String alias=Build.VERSION.SDK_INT>=33?"photos":"legacy";if(getPermissionState(alias)!=PermissionState.GRANTED){requestPermissionForAlias(alias,call,"permissionResult");return;}select(call);}
 @PermissionCallback private void permissionResult(PluginCall call){String alias=Build.VERSION.SDK_INT>=33?"photos":"legacy";if(getPermissionState(alias)==PermissionState.GRANTED)select(call);else call.reject("Allow full photo access in Settings.");}
 private void select(PluginCall call){new Thread(()->{try{Calendar cal=Calendar.getInstance();cal.clear();cal.set(2026,0,1);long start=cal.getTimeInMillis();cal.set(2027,0,1);long end=cal.getTimeInMillis();ArrayList<Uri> ids=new ArrayList<>();Uri base=MediaStore.Images.Media.EXTERNAL_CONTENT_URI;try(Cursor c=getContext().getContentResolver().query(base,new String[]{"_id"},"datetaken >= ? AND datetaken < ?",new String[]{""+start,""+end},null)){if(c!=null)while(c.moveToNext())ids.add(ContentUris.withAppendedId(base,c.getLong(0)));}Collections.shuffle(ids);JSArray photos=new JSArray();for(Uri u:ids){try{Bitmap b;if(Build.VERSION.SDK_INT>=28){b=ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContext().getContentResolver(),u),(d,info,src)->{int w=info.getSize().getWidth(),h=info.getSize().getHeight();float scale=Math.min(1f,1000f/Math.max(w,h));d.setTargetSize(Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)));d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);});}else{continue;}ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,88,out);b.recycle();photos.put(Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));if(photos.length()==12)break;}catch(Exception ignored){}}if(photos.length()!=12){call.reject("12 readable 2026 photos required. Check full photo permission.");return;}JSObject result=new JSObject();result.put("photos",photos);call.resolve(result);}catch(Exception e){call.reject("Unable to read photos.",e);}}).start();}
 @PluginMethod public void shareCollage(PluginCall call){try{File dir=new File(getContext().getCacheDir(),"shared");dir.mkdirs();File f=new File(dir,"26wrapped-2026.jpg");try(FileOutputStream out=new FileOutputStream(f)){out.write(Base64.decode(call.getString("data"),Base64.DEFAULT));}Uri u=FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/jpeg");i.putExtra(Intent.EXTRA_STREAM,u);i.setClipData(ClipData.newRawUri("26wrapped",u));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);getActivity().runOnUiThread(()->{getActivity().startActivity(Intent.createChooser(i,"Share"));call.resolve();});}catch(Exception e){call.reject("Unable to share.",e);}}
}
