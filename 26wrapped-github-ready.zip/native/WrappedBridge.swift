import Capacitor
class WrappedBridge: CAPBridgeViewController { override func capacitorDidLoad() { bridge?.registerPluginInstance(CameraRollPlugin()) } }
